		<FOOTER>
			<P>Este es el pie de página</P>
			<DIV id="cajaEnlacesFooter">
				<NAV>
					<UL>
						<LI><A href="#" title="Link 1">Enlace 1</A></LI>
						<LI><A href="#" title="Link 2">Enlace 2</A></LI>
						<LI><A href="#" title="Link 3">Enlace 3</A></LI>
						<LI><A href="#" title="Link 4">Enlace 4</A></LI>
					</UL>
				</NAV>

				<NAV>
					<UL>
						<LI><A href="#" title="Link 1">Enlace 1</A></LI>
						<LI><A href="#" title="Link 2">Enlace 2</A></LI>
						<LI><A href="#" title="Link 3">Enlace 3</A></LI>
						<LI><A href="#" title="Link 4">Enlace 4</A></LI>
					</UL>
				</NAV>

				<NAV>
					<UL>
						<LI><A href="#" title="Link 1">Enlace 1</A></LI>
						<LI><A href="#" title="Link 2">Enlace 2</A></LI>
						<LI><A href="#" title="Link 3">Enlace 3</A></LI>
						<LI><A href="#" title="Link 4">Enlace 4</A></LI>
					</UL>
				</NAV>
			</DIV>
			<P>Sitio creado por <A href="mailto:tecnico@fryntiz.es" title="Enviar correo a Fryntiz">tecnico@fryntiz.es</A>, puedes visitar mi web <A href="http://www.fryntiz.es" title="Web del programador Fryntiz" target="_blank">www.fryntiz.es</A></P>
			<P><SMALL>Licencia GPLv3 comparte y reconoce al autor | 2016 Creado y diseñado originalmente por Raúl Caro Pastorino</SMALL></P>

			<A id="subir" href="#titulo" rel="nofollow" title="Subir"><DIV>Subir</DIV></A>
		</FOOTER>
