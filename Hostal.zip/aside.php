			<ASIDE>
				<H4>Consultas Rápidas</H4>
				<UL>
					<LI><A href="form-clientes.php" title="Crear nuevo cliente">Crear Cliente</A></LI>
					<LI><A href="form-reservas.php" title="Ver habitaciones libres">Ver habitaciones libres</A></LI>
					<LI><A href="#" title="Crear nueva reserva">Crear Reserva</A></LI>
					<LI><A href="#" title="Eliminar Reserva">Eliminar Reserva</A></LI>
					<LI><A href="#" title="Ver calendario">Ver calendario</A></LI>
				</UL>
			</ASIDE>
