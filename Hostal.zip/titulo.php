		<HEADER id="cajaTitulo">
			<FIGURE>
				<IMG src="./img/logo.png" alt="Mi Logo" title="Logotipo del sitio web" longdesc="http://www.miweb.es/index.html#descripcionweb" />
				<FIGCAPTION>
					<H1 id="titulo">Paraiso Hotel</H1>
					<P id="descripcionweb">HOTEL & RESORT</P>
				</FIGCAPTION>
			</FIGURE>
		</HEADER>
