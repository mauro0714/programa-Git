				<ARTICLE>
					<HEADER>
						<H2>Últimas Reservas</H2>
						<P>Estas son las últimas reservas que se han realizado</P>
						<TIME datetime="2017-02-14T12:30:00+01:00"><SMALL>Creado el 14-02-2017 a las 12:30</SMALL></TIME>
					</HEADER>

					<SECTION>
						<H3>Reservas de hoy</H3>
						<P>Estas son las reservas realizadas hoy</P>
					</SECTION>

					<SECTION>
						<H3>Otras reservas</H3>
						<P>Datos de otras reservas realizadas</P>
					</SECTION>
				</ARTICLE>

				<HR />

				<ARTICLE>
					<HEADER>
						<H2>Últimos clientes</H2>
						<P>Datos de los últimos clientes registrados</P>
						<TIME datetime="2017-02-14T01:20:00+01:00"><SMALL>Creado el 14-02-2017 a las 01:20</SMALL></TIME>
					</HEADER>

					<SECTION>
						<H3>Clientes registrados hoy</H3>
						<P>Detalles de los clientes registrados hoy</P>
					</SECTION>

					<SECTION>
						<H3>Otros clientes registrados</H3>
						<P>Datos los clientes registrados</P>
					</SECTION>
				</ARTICLE>

				<ARTICLE>
					<HEADER>
						<H2>Habitaciones Libres</H2>
						<P>Detalles de las habitaciones aún no ocupadas</P>
						<TIME datetime="2017-02-14T01:20:00+01:00"><SMALL>Creado el 14-02-2017 a las 01:20</SMALL></TIME>
					</HEADER>

					<SECTION>
						<H3>Habitaciones libres para esta semana</H3>
						<P>Estas habitaciones están algún día de esta semana libre</P>
					</SECTION>

					<SECTION>
						<H3>Habitaciones libres algún día de este mes</H3>
						<P>Estas habitaciones están algún día de este mes libre</P>
					</SECTION>
				</ARTICLE>
